package com.cssun.quizapp2;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
public class QuizActivity extends AppCompatActivity {

    private TextView questionTextView;
    private RadioGroup optionsRadioGroup;
    private Button nextButton;

    private Button quitButton;
    private TextView resultTextView;
    private String[] questions;
    private String[][] options;
    private int[] correctAnswers;
    private int currentQuestionIndex;
    private int correctCount;
    private String userName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        questionTextView = findViewById(R.id.questionTextView);
        optionsRadioGroup = findViewById(R.id.optionsRadioGroup);
        nextButton = findViewById(R.id.nextButton);
        quitButton = findViewById(R.id.quitButton);
        resultTextView = findViewById(R.id.resultTextView);

        userName = getIntent().getStringExtra("userName");

        initializeQuiz();

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer();
            }
        });
        quitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishQuiz();
            }
        });
    }
    private void finishQuiz() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Quit Quiz")
                .setMessage("Are you sure you want to quit the quiz?")
                .setPositiveButton("Quit", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        showResult();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void initializeQuiz() {
        // Initialize the questions array
        questions = getResources().getStringArray(R.array.questions_array);

        // Initialize the options array
        options = new String[questions.length][4];
        for (int i = 0; i < questions.length; i++) {
            String optionsArrayName = "options_q" + (i + 1) + "_array";
            options[i] = getResources().getStringArray(getResources().getIdentifier(optionsArrayName, "array", getPackageName()));
        }

        // Initialize the correct answers array
        correctAnswers = getResources().getIntArray(R.array.correct_answers_array);

        currentQuestionIndex = 0;
        correctCount = 0;

        showQuestion();
    }


    private void showQuestion() {
        if (currentQuestionIndex < questions.length) {
            String question = questions[currentQuestionIndex];
            questionTextView.setText(question);

            // Clear the previously selected radio button
            optionsRadioGroup.clearCheck();

            // Set the options for the current question
            String[] currentOptions = options[currentQuestionIndex];
            for (int i = 0; i < optionsRadioGroup.getChildCount(); i++) {
                RadioButton radioButton = (RadioButton) optionsRadioGroup.getChildAt(i);
                radioButton.setText(currentOptions[i]);
            }

        } else {
            showResult();
        }
    }

    private void checkAnswer() {
        int selectedId = optionsRadioGroup.getCheckedRadioButtonId();
        if (selectedId != -1) {
            RadioButton selectedRadioButton = findViewById(selectedId);
            String selectedAnswer = selectedRadioButton.getText().toString();

            int correctAnswerIndex = correctAnswers[currentQuestionIndex];
            String correctAnswer = options[currentQuestionIndex][correctAnswerIndex];

            boolean isCorrect = selectedAnswer.equals(correctAnswer);

            if (isCorrect) {
                correctCount++;
            }

            currentQuestionIndex++;
            showQuestion();
        }
    }

    private void showResult() {
        int totalQuestions = questions.length;
        int percentage = (correctCount * 100) / totalQuestions;

        String resultMessage = "Congratulations, " + userName + "!\nYou scored " + correctCount +
                " out of " + totalQuestions + " (" + percentage + "%).";

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Quiz Result")
                .setMessage(resultMessage)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish(); // Close the activity after displaying the result
                    }
                })
                .setCancelable(false)
                .show();

        questionTextView.setVisibility(View.GONE);
        optionsRadioGroup.setVisibility(View.GONE);
        nextButton.setVisibility(View.GONE);
        resultTextView.setVisibility(View.GONE);
    }

}